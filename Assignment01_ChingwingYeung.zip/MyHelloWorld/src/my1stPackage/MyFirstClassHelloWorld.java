// Assignment 01
// 8/29/2022
// Chingwing Yeung
// CIS016 

package my1stPackage;

public class MyFirstClassHelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World.");
	}

}
