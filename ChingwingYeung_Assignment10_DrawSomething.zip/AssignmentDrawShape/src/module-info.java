module AssignmentDrawShape {
	requires javafx.controls;
	
	opens drawShapesPKG to javafx.graphics, javafx.fxml;
}
