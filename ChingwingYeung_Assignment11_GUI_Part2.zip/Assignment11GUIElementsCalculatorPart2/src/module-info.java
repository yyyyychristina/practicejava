module Assignment11GUIElementsCalculator {
	requires javafx.controls;
	
	opens myJavaFXpkg to javafx.graphics, javafx.fxml;
}
