package myBulgarianSolitairePackage;

public class BulgarianSolitaire {
    //invoke methods
    public static void main(String[] args) {
    	BulgarianSolitaire game1 = new BulgarianSolitaire();
        int[] game1thelist = game1.initializingPiles();
        
        for (int i = 0; i < game1thelist.length; i++) {
        	System.out.println(game1thelist[i]);
        }
        int[] game1thelistnew = formingNewPile(game1thelist);
        for (int i = 0; i < game1thelistnew.length; i++) {
        	System.out.println(game1thelistnew[i]);
        }
        
    }
    
    
    
	int numberOfCards = 45; //what class knows
    int startNumberOfPiles;   // what class knows
    

    /**Construct BulgarianSolitaire with startNumberOfPiles 1  */
    BulgarianSolitaire() {
        startNumberOfPiles = 4;
    }
    

    /** Construct BulgarianSolitaire with a specified startNumberOfPiles */
    BulgarianSolitaire(int newStartNumberOfPiles) {
        startNumberOfPiles = newStartNumberOfPiles;
    }
    
    
    /**what class do: initializing the 4 piles(startNumberOfPiles) at first*/
    public int[] initializingPiles() {
      //create an array called a round to store piles of cards
      int round[] = new int[startNumberOfPiles];





      //make a for loop to populate a random number until  numberOfcard is zero
      int remainingCards = numberOfCards;
      for (int i = 0; i < startNumberOfPiles - 1; i++) {
          round[i] = (int)(Math.random() * startNumberOfPiles);
          remainingCards -= round[i];
      }
      round[startNumberOfPiles-1] = remainingCards;
      return round;
    }
    
  
    /**what class do: forming new piles
     * @return */
    public static int[] formingNewPile(int round[]) {
    //array round has four piles now
     
    	
    	/**make an NEW array called newRound to stored (each piles-1) and newPile 
          *get one card from each piles 
          *newPile = round.length                                           */

          int[] newRound = new int[round.length + 1];
          System.arraycopy(round, 0, newRound, 0, round.length);  
            
            
          /**use while loop?*/
          //if newRound[i] = i + 1 
          /**e.g. for newRound = {1, 2, 3, 4, 5, 6, 7, 8, 9} then end the loop
            * while newRound[i] = i+1*/
          for (int i = 0; i < newRound.length; i++) {
        	  while (newRound[i] != i+1){
            		
            	
            	
            	    /**first loop*/
                	for (int j = 0; j < newRound.length - 1; j++){
                		//if round[j] == 0 , skip and continue
                		if (newRound[j] == 0) {
                			continue;
                		}
                        newRound[j] = newRound[j] - 1;
                    }
                    //newRound[round.length] = round.length;
                    newRound[round.length] = round.length;
                    
                    //invoke a method to sort the newRound array in ascending order using for loop 
                    selectionSort(newRound);
                    
                    
                	/**make an NEW array called newRound to stored (each piles-1) and newPile 
                     *get one card from each piles 
                     *newPile = round.length                                           */
                    newRound = new int[newRound.length + 1];
                    System.arraycopy(newRound, 0, newRound, 0, newRound.length); 
                    

                    

                    	
                    
                    /**first loop*/
                    
            	}
                
            }
		return newRound;
            
        	

            
        
        
        
        
        
        
        
        
    }
    //what a class does: sort the newRound array in ascending order using for loop 
    public static int[] selectionSort(int[] newRound) {
    	for (int i = 0; i < newRound.length - 1; i++) {
    		//find the minimum in the list [i...list.length-1]
    		int currentMin = newRound[i];
    		int currentMinIndex = i;
    		
    		for (int j = i + 1; j < newRound.length; j++) {
    			if (currentMin > newRound[j]) {
    				currentMin = newRound[j];
    				currentMinIndex = j;
    			}
    		}
    		//swap list[i] with list[currentMinIndex] of necessary
    		if (currentMinIndex != i) {
    			newRound[currentMinIndex] = newRound[i];
    			newRound[i] = currentMin;
    		}
    		
    	}
    	return newRound;
    	
    }
            
       

}


